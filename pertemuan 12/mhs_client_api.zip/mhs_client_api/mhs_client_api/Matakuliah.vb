﻿Public Class Matakuliah
    Public Property kodemk As String
    Public Property namamk As String
    Public Property sks As String
    Public Property prodi As String
End Class
