﻿Public Class Mahasiswa
    Public Property nim As String
    Public Property nama As String
    Public Property jk As String
    Public Property prodi As String
    ' Add more properties as needed to match the structure of the JSON data
End Class