﻿Public Class Dosen2

End Class